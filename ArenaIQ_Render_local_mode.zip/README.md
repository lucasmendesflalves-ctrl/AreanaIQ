ArenaIQ - Render (Local Mode) - MVP

This package is pre-configured to run on Render (or similar hosting).
It uses a local analysis engine (no external AI required).

Files included:
- main.py         -> FastAPI backend (local analysis)
- requirements.txt
- runtime.txt     -> Python runtime version for Render
- Procfile        -> Start command for Render
- .env.example    -> Example environment variables

How to deploy on Render (quick):
1. Create a new Web Service on Render and connect your GitHub repo (or upload this zip).
2. Ensure files are in repo root.
3. Set Environment Variables in Render (at minimum):
   - ADMIN_TOKEN (ex: mySecretToken)
4. Deploy. The service should start and /api/health will respond with {"status":"ok"}.
5. Use the admin UI: /admin/ui (POST forms require admin_token)
6. Point your frontend to the Render URL (e.g. https://your-app.onrender.com) and use /api/analysis endpoint.

Local test:
1. python -m venv venv
2. source venv/bin/activate   (or venv\Scripts\activate on Windows)
3. pip install -r requirements.txt
4. export ADMIN_TOKEN=changeme
5. uvicorn main:app --reload --port 10000
6. Open http://localhost:10000/api/health
