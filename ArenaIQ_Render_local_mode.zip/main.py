# main.py - ArenaIQ (local mode)
import os
import time
import asyncio
import sqlite3
import json
from typing import List, Dict, Any, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Form, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

LOG_PREFIX = "[ArenaIQ]"

APP_PORT = int(os.getenv("PORT", "10000"))
DB_FILE = os.getenv("DB_FILE", "arena.db")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "changeme")
POLL_INTERVAL = int(os.getenv("POLL_INTERVAL", "60"))

app = FastAPI(title="ArenaIQ - Local Mode (MVP)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)

# --- Database helpers (SQLite) ---
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS matches (
        match_id TEXT PRIMARY KEY,
        sport TEXT,
        home TEXT,
        away TEXT,
        score_home INTEGER,
        score_away INTEGER,
        status TEXT,
        start_ts INTEGER,
        raw TEXT,
        updated_ts INTEGER
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS probabilities (
        key TEXT PRIMARY KEY,
        summary TEXT,
        probabilities TEXT,
        confidence REAL,
        ts INTEGER
    )
    """)
    conn.commit()
    conn.close()

def db_upsert_match(m: Dict[str, Any]):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""INSERT OR REPLACE INTO matches(match_id,sport,home,away,score_home,score_away,status,start_ts,raw,updated_ts)
    VALUES(?,?,?,?,?,?,?,?,?,?)""", (
        m.get("match_id"),
        m.get("sport"),
        m.get("home"),
        m.get("away"),
        m.get("score_home"),
        m.get("score_away"),
        m.get("status","scheduled"),
        m.get("start_ts"),
        json.dumps(m.get("raw") or {}),
        int(time.time())
    ))
    conn.commit()
    conn.close()

def db_get_recent_matches_for_team(team: str, limit: int = 20):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""SELECT home,away,score_home,score_away FROM matches
                   WHERE (home=? OR away=?) AND score_home IS NOT NULL
                   ORDER BY updated_ts DESC LIMIT ?""", (team, team, limit))
    rows = cur.fetchall()
    conn.close()
    return [{"home": r[0], "away": r[1], "score_home": r[2], "score_away": r[3]} for r in rows]

def db_save_probability(key: str, summary: str, probabilities: Dict[str, float], confidence: float):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""INSERT OR REPLACE INTO probabilities(key,summary,probabilities,confidence,ts)
    VALUES(?,?,?,?,?)""", (key, summary, json.dumps(probabilities), confidence, int(time.time())))
    conn.commit()
    conn.close()

def db_get_matches_all():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT match_id,sport,home,away,score_home,score_away,status,start_ts,raw FROM matches ORDER BY updated_ts DESC LIMIT 200")
    rows = cur.fetchall()
    conn.close()
    out = []
    for r in rows:
        out.append({"match_id": r[0], "sport": r[1], "home": r[2], "away": r[3],
                    "score_home": r[4], "score_away": r[5], "status": r[6], "start_ts": r[7], "raw": json.loads(r[8] or "{}")})
    return out

# --- Simple local probability engine ---
def simple_prob_engine(recent_matches: List[Dict[str, Any]], teamA: str, teamB: str):
    def team_form(team):
        played = [m for m in recent_matches if m.get("home") == team or m.get("away") == team][-10:]
        if not played:
            return 0.5
        score = 0.0; weight = 0.0; w = 1.0
        for m in reversed(played):
            isHome = (m.get("home") == team)
            gf = m.get("score_home") if isHome else m.get("score_away")
            ga = m.get("score_away") if isHome else m.get("score_home")
            res = 0.5
            if gf is not None and ga is not None:
                if gf > ga: res = 1.0
                elif gf < ga: res = 0.0
            if isHome: res += 0.05
            score += res * w; weight += w; w += 0.3
        return score / weight if weight > 0 else 0.5

    formA = team_form(teamA); formB = team_form(teamB)
    rawA = formA * 0.6 + (1 - formB) * 0.25
    rawB = formB * 0.6 + (1 - formA) * 0.25
    diff = abs(rawA - rawB)
    draw = max(0.12, 0.28 - diff * 0.25)
    denom = (rawA + rawB) if (rawA + rawB) > 0 else 1
    winA = rawA * (1 - draw) / denom
    winB = rawB * (1 - draw) / denom
    s = winA + winB + draw
    return {"home": round(winA / s, 4), "draw": round(draw / s, 4), "away": round(winB / s, 4)}

# --- WebSocket manager ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
    def disconnect(self, websocket: WebSocket):
        try:
            self.active_connections.remove(websocket)
        except Exception:
            pass
    async def broadcast(self, message: Dict[str, Any]):
        for conn in list(self.active_connections):
            try:
                await conn.send_json(message)
            except Exception:
                try:
                    self.active_connections.remove(conn)
                except Exception:
                    pass

manager = ConnectionManager()

# --- Models ---
class AnalysisRequest(BaseModel):
    sport: str
    teamA: str
    teamB: str
    recentMatches: Optional[List[Dict[str, Any]]] = None
    headlines: Optional[List[str]] = None

# --- Background poller (minimal, local mode) ---
async def poller_task():
    while True:
        try:
            # In local mode this poller does nothing unless you implement fetch_sports_updates
            # It is left here so you can add automatic fetch later.
            await asyncio.sleep(max(5, POLL_INTERVAL))
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(5)

@app.on_event("startup")
async def on_startup():
    init_db()
    app.state.poller = asyncio.create_task(poller_task())

# --- Endpoints ---
@app.get("/api/health")
async def health():
    return {"status": "ok", "ts": int(time.time())}

@app.post("/api/analysis")
async def analysis(req: AnalysisRequest):
    recent = []
    recent += db_get_recent_matches_for_team(req.teamA)
    recent += db_get_recent_matches_for_team(req.teamB)
    if req.recentMatches:
        recent = recent + req.recentMatches
    probs = simple_prob_engine(recent, req.teamA, req.teamB)
    # summary local (simple)
    summary = f"Análise local: {req.teamA} vs {req.teamB}. Baseada em {len(recent)} partidas recentes."
    key = f"{req.teamA}__{req.teamB}"
    db_save_probability(key, summary, probs, 0.55)
    return {"summary": summary, "probabilities": probs, "confidence": 0.55}

@app.post("/api/matches")
async def ingest_match(payload: Dict[str, Any]):
    if not payload.get("match_id"):
        payload["match_id"] = f\"{payload.get('home')}_{payload.get('away')}_{int(time.time())}\"
    db_upsert_match(payload)
    # broadcast update
    await manager.broadcast({"type": "match_update", "payload": payload})
    return {"ok": True, "match_id": payload["match_id"]}

@app.get("/api/matches")
async def list_matches():
    return {"count": len(db_get_matches_all()), "matches": db_get_matches_all()}

@app.websocket("/ws/updates")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True:
            await ws.receive_text()  # keep alive
    except WebSocketDisconnect:
        manager.disconnect(ws)
    except Exception:
        manager.disconnect(ws)

# --- Admin endpoints (simple form-based) ---
def require_admin(token: str):
    if token != ADMIN_TOKEN:
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.post("/admin/add_match")
async def admin_add_match(request: Request):
    form = await request.form()
    admin_token = form.get("admin_token") or request.headers.get("x-admin-token")
    require_admin(admin_token)
    m = {
        "match_id": form.get("match_id") or f\"{form.get('home')}_{form.get('away')}_{int(time.time())}\",
        "sport": form.get("sport") or "futebol",
        "home": form.get("home"),
        "away": form.get("away"),
        "score_home": int(form.get("score_home")) if form.get("score_home") else None,
        "score_away": int(form.get("score_away")) if form.get("score_away") else None,
        "status": form.get("status") or "scheduled",
        "start_ts": int(form.get("start_ts")) if form.get("start_ts") else None,
        "raw": {}
    }
    db_upsert_match(m)
    await manager.broadcast({"type": "match_update", "payload": m})
    return JSONResponse({"ok": True, "match": m})

@app.post("/admin/trigger_poll")
async def admin_trigger_poll(admin_token: str = Form(...)):
    require_admin(admin_token)
    # in local mode, trigger poll does nothing but return OK
    return {"ok": True, "fetched": 0}

@app.get("/admin/ui", response_class=HTMLResponse)
async def admin_ui():
    html = \"\"\"<!doctype html><html><head><meta charset='utf-8'><title>ArenaIQ Admin</title></head><body>
    <h3>ArenaIQ Admin</h3>
    <form method='post' action='/admin/add_match'>
      <input name='admin_token' placeholder='ADMIN_TOKEN' style='width:300px'><br>
      <input name='sport' placeholder='sport' value='futebol'><br>
      <input name='home' placeholder='home'><br>
      <input name='away' placeholder='away'><br>
      <input name='score_home' placeholder='score_home'><br>
      <input name='score_away' placeholder='score_away'><br>
      <button type='submit'>Adicionar partida</button>
    </form>
    <hr>
    <form method='post' action='/admin/trigger_poll'>
      <input name='admin_token' placeholder='ADMIN_TOKEN' style='width:300px'><button type='submit'>Trigger Poll</button>
    </form>
    <p>Use the admin_token you set in environment variables.</p>
    </body></html>\"\"\"
    return HTMLResponse(content=html)
